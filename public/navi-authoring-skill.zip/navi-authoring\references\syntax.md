# Navi Syntax Reference

Complete surface syntax for **Navi** (`.nvs`) — a Rust-style language with brace
blocks and `;` terminators. Each statement must end with exactly one `;`
(block-bearing statements like `fn`/`if`/`for`/`while`/`switch`/`struct`/`enum`
end with `}` and do not take a trailing `;`). Whitespace and newlines are
insignificant; they only separate tokens.

All examples here are **Navi syntax** (`.nvs` files).

## Table of Contents

- [Source structure](#source-structure)
- [Comments and doc annotations](#comments-and-doc-annotations)
- [Basic types](#basic-types)
- [Collection types](#collection-types)
- [Tuples](#tuples)
- [Variable declarations](#variable-declarations)
- [Reassignment](#reassignment)
- [Control flow](#control-flow)
- [Functions](#functions)
- [Special functions](#special-functions-method-property-staticmethod-operator)
- [Type declarations](#type-declarations-struct-enum-newtype)
- [Imports and exports](#imports-and-exports)
- [Compiler-special types](#compiler-special-types)
- [Statement & expression catalog](#statement--expression-catalog)

## Source structure

A Navi program is a sequence of statements separated (and optionally terminated)
by `;`. Blocks are delimited by braces `{ … }`; a block's value is its **last
statement** (no trailing `;` on it).

```navi
indicator("My Indicator");
let length = 14;
plot(ta.sma(close, length));
```

```navi
fn add(a, b) {
    let sum = a + b;
    sum // block value — no trailing ;
}
```

Statements that end in a block (function/struct/enum declarations, control-flow
statements) take no trailing `;`. Indentation is stylistic (4 spaces by
convention); long expressions may span lines freely.

## Comments and doc annotations

Line comments use `//`. Documentation annotations attach to the **following
declaration** and use the `//@tag` form (a space, `// @tag`, is also accepted):

```navi
//@function Outputs a label on the bar's high.
//@param labelText The text to display.
//@returns The drawn label.
export fn drawLabel(labelText: string) {
    label.new(bar_index, high, text: labelText)
}
```

| Tag | Placement | Describes |
|-----|-----------|-----------|
| `@description` | script header | the script itself |
| `@function` | above a function | the function |
| `@param` | above a function | a parameter (name + description) |
| `@returns` | above a function | the return value |
| `@type` | above a `struct` | the object type |
| `@enum` | above an `enum` | the enum |
| `@field` | above a `struct`/`enum` | a field / variant |
| `@variable` | above a variable | the variable |

Compiler directives use the `@name` form (no `//`) and precede a declaration,
e.g. `@directive`, `@drawid`, `@bardata`.

## Basic types

| Type | Description | Literal examples |
|------|-------------|------------------|
| `int` | 64-bit integer | `42`, `-123`, `+5` |
| `float` | 64-bit float | `3.14`, `.5`, `3.`, `1e-3`, `1.2E+5` |
| `bool` | boolean | `true`, `false` |
| `string` | text (single or double quotes) | `"hello"`, `'hello'` |
| `color` | RGBA color | `#FF0000`, `#FF000080` |

String escapes: `\\`, `\n`, `\r`, `\t`, `\"` or `""`, `\'` or `''`. Color
literals are `#RRGGBB` (opaque) or `#RRGGBBAA` (with alpha); named constants
come from `color.*` (uppercase, e.g. `color.RED`).

`na` is a missing value assignable to any type. It needs an explicit annotation
when used alone:

```navi
let a: float = na; // OK
let a = na;        // error: cannot infer type
```

## Collection types

| Type | Description |
|------|-------------|
| `array<T>` | ordered, indexable sequence |
| `matrix<T>` | 2D table |
| `map<K, V>` | key-value store (key must be int/float/bool/string/color/enum) |

```navi
let arr: array<int> = Array.new<int>(3, 0);
let m: matrix<float> = Matrix.new<float>(2, 3);
let prices: map<string, float> = Map.new<string, float>();
```

Array and map literals support inline initialization:

```navi
let values = [1, 2, 3];                 // array<int>
let floats: array<float> = [1, 2, 3];   // widened to float
let counts = {"a": 1, "b": 2};          // map<string, int>
let empty_arr: array<int> = [];         // type from the annotation
let empty_map: map<string, int> = {};
```

## Tuples

Tuples use **parentheses** `(a, b)`. A single-element tuple needs a trailing
comma `(a,)`; plain `(expr)` is grouping, not a tuple.

```navi
fn calculate(x, y) {
    (x + y, x - y)
}

let (sum, diff) = calculate(10, 3);
let (_, secondOnly) = calculate(10, 3); // _ discards an element
```

> **Constraint:** tuples may only appear as **function return values** and must
> be **immediately destructured** on assignment. They cannot be stored in a
> variable, passed as arguments, or nested inside other expressions.

## Variable declarations

Declarations are introduced by `let`, `var`, or `varip`. A bare `name = expr`
(no keyword) is a **reassignment**, never a declaration.

```navi
let a = 1;             // inferred type
let b: float = 2.0;    // type annotation (name: type)
let c: const int = 3;  // with a type qualifier
var counter = 0;       // persists across bars
varip ticks = 0;       // persists across intrabar ticks
```

Type qualifiers (`const`, `input`, `simple`, `series`) precede the type in an
annotation: `let x: series float = close;`. The runtime behavior of `var`,
`varip`, and the qualifiers is covered in
[execution-model.md](execution-model.md).

Tuple destructuring uses `let (a, b) = …`; history references use the `[]`
suffix (`close[1]` is the previous bar's `close`):

```navi
let (basis, upper, lower) = ta.bb(close, 20, 2.0);
let change = close - close[1];
```

## Reassignment

Bare `=` reassigns an existing variable; compound operators are supported:

```navi
let a = 10;
a = 20;   // reassign
a += 5;   // also -=, *=, /=, %=
```

## Control flow

All control structures are **expressions** — the last expression evaluated in
the executed branch/iteration is the value. So `if`, `for`, `while`, and
`switch` can appear on the right-hand side of an assignment.

### `if` / `else if` / `else`

```navi
if close > open {
    label.new(bar_index, high, "Bullish");
} else if close < open {
    label.new(bar_index, low, "Bearish");
} else {
    label.new(bar_index, close, "Doji");
}

let x = if close > open { close } else { open };
```

When `else` is omitted, the result is `na` (or `false` / `""` for bool/string)
if the condition is false. Branches may return tuples, but every branch must
share the same shape and type.

### `for` (numeric range)

```navi
let sum = 0.0;
for i = 0 to 9 {
    sum += close[i];
}

for i = 0 to 20 by 2 { }    // step
for i = 10 to 0 by -1 { }   // reverse
```

### `for`-in (collection iteration)

```navi
for value in prices {
    log.info(str.tostring(value));
}

for (index, value) in prices {
    log.info(str.tostring(index) + ": " + str.tostring(value));
}
```

### `while`

```navi
let i = 0;
while i < 10 {
    i += 1;
}
```

A loop returns the last expression of its final iteration, or `na` if no
iteration runs. `break` exits (returning the last value evaluated before it);
`continue` skips to the next iteration.

### `switch`

Inline branches end with `,`; brace-block branches omit the `,` (they end
with `}`); `=>` with no left side is the default (fallback) branch.

```navi
// With a subject — inline branches use `,`
let ma = switch maType {
    "EMA" => ta.ema(close, 10),
    "SMA" => ta.sma(close, 10),
    => ta.wma(close, 10),
};

// Condition-based (no subject)
let direction = switch {
    close > open => "up",
    close < open => "down",
    => "flat",
};

// Multi-statement branch: use a brace block (no trailing `,`)
let label = switch dayOfWeek {
    1 => "Mon",
    2 => {
        let s = "Tue";
        s;
    }
    => "other",
};
```

## Functions

Regular functions use `fn`. Parameters are `name: type` (type optional — omit to
infer); the return type follows as `): type` (also optional; `: void` for no
return). Every statement — including the last — ends with `;`.

```navi
fn add(a, b) {
    a + b;
}

fn weighted(a: float, b: float, w: float): float {
    a * w + b * (1.0 - w)
}

fn logValue(v: float): void {
    log.info(str.tostring(v));
}
```

Default parameter values use `= expr`; the last parameter may be variadic with
`...`; type parameters are declared with `<…>`; tuple return types use `): (T, U)`:

```navi
fn make(a: int, b: int = 10) { a + b }
fn sum(values: int...): int { values.sum() }
fn first<T>(xs: array<T>): T { xs.get(0) }
fn minmax(xs: array<float>): (float, float) { (xs.min(), xs.max()) }
```

**Overloading:** several functions may share a name with different parameter
types.

```navi
fn format(x: int) { str.tostring(x) }
fn format(x: float) { str.tostring(x, "#.##") }
fn format(x: string) { x }
```

> **No recursion.** A function cannot call itself directly or indirectly; the
> compiler rejects any call cycle. Use `for`/`while` for iteration instead.

Call functions positionally or with named arguments: `plot(close, title: "Close", color: color.BLUE)`.

## Special functions (`method`, `property`, `staticmethod`, `staticproperty`, `operator`)

These lead with a keyword instead of `fn`.

```navi
// method — first parameter is the receiver `self`; two equivalent call forms:
method double(self: int): int {
    self * 2
}
// let x = 5;
// x.double()   // dot-call
// double(x)    // UFCS: receiver as first argument — identical semantics

// property — zero-parameter accessor, referenced WITHOUT parentheses
property halfPi(): const float {
    3.14159 / 2.0
}
// let x = halfPi; // calling halfPi() is an error

// staticmethod(Type) — associated function called on the type name WITH parentheses
staticmethod(Vec2) zero(): Vec2 {
    Vec2.new(0.0, 0.0)
}
// let z = Vec2.zero();

// staticproperty(Type) — zero-parameter accessor on the type name, NO parentheses
staticproperty(Vec2) origin(): Vec2 {
    Vec2.new(0.0, 0.0)
}
// let o = Vec2.origin;   // no () — like a property but on the type

// operator — overload +, -, *, / for user-defined types (no space after `operator`)
operator+(a: Vec2, b: Vec2): Vec2 {
    Vec2.new(a.x + b.x, a.y + b.y)
}
```

`staticmethod`, `staticproperty`, and `operator` are only valid for `struct` or `newtype` types (not enums or primitives).

## Type declarations (struct, enum, newtype)

**struct** — fields keep `type name` order, separated by `,`; fields may carry a
default (`= expr`) or a `varip` declaration mode:

```navi
struct Order {
    int id,
    string symbol,
    float price = na,
    varip int updateCount = 0,
}

let o: Order = Order.new(id: 1, symbol: "AAPL");
let price = o.price;      // field access
o.price = 155.0;          // field reassignment (bare =)
let clone: Order = Order.copy(o);
```

Structs accept type parameters (generic structs). Fields may reference the
parameters, including parameterized collection types:

```navi
struct Pair<A, B> {
    A first,
    B second,
}

struct Stack<T> {
    Array<T> items,
    int count = 0,
}

let p: Pair<int, float> = Pair.new(first: 1, second: 3.14);
let s: Stack<string> = Stack.new();
```

**enum** — variants separated by `,`, PascalCase by convention, optionally with
a title:

```navi
enum Trend {
    Up,
    Down,
    Both = "Both Directions",
}

let d: Trend = Trend.Up;
```

**newtype** — alias an existing type with `type Name = Underlying;` (may be
layered):

```navi
type Price = float;
type IntArray = array<int>;
```

## Imports and exports

Import modules with `use`, optionally aliased with `as`; mark declarations
`export` to make them visible to importers.

```navi
use my_org/helpers/1 as h; // versioned module path
use mylib as lib;           // access as lib.*

export fn add(a: int, b: int) { a + b }
export struct Point { float x, float y, }
export enum Side { Left, Right, }
```

## Compiler-special types

These appear in stdlib source and are handled transparently when you call the
relevant built-ins — you rarely write them yourself.

- **`expression`** — receives an *unevaluated AST node* instead of a value. Used
  by `input.source()` so the UI can display the source by name.
- **`instructions<T>`** — receives a *compiled code block* re-executed in a
  different context. Used by `request.security()` to run an expression on
  another symbol/timeframe.
- **`variableref`** — a *compile-time reference* to a variable/series. Used by
  `max_bars_back()` to extend a series' history buffer.

```navi
let src = input.source(close);                 // `close` captured as expression
let aaplSma = request.security("AAPL", "1D", ta.sma(close, 14));
max_bars_back(close, 500);
```

## Statement & expression catalog

Use as a checklist when implementing or reviewing Navi code.

**Statements**

- Script declaration: `indicator(...);`, `strategy(...);`, `library(...);`
- Declarations: `let x = …;`, `let x: int = …;`, `var x = …;`, `varip x = …;`
- Reassignment: `x = expr;`; compound `x += expr;`, `-=`, `*=`, `/=`, `%=`
- Blocks: `{ … }`, `;`-separated; last statement is the value
- `if cond { … } else if cond2 { … } else { … }`
- `for i = 0 to n { … }` (optional `by step`)
- `for v in arr { … }`, `for (k, v) in m { … }`
- `while cond { … }`; loop control `break;`, `continue;`
- `switch x { 1 => …, => …, }` / `switch { cond => …, => …, }`
- `fn f(x, y) { … }`, typed `fn f(x: float): float { … }`
- `method`, `property`, `staticmethod(T)`, `staticproperty(T)`, `operator+` declarations
- `struct T { … }`, `enum E { … }`, `type N = U;`
- `export …`, `use <lib> as <alias>;`

**Expressions**

- Identifiers: `x`, `_` (discard)
- Literals: numbers, `true`/`false`, strings, colors, `na`
- Grouping `(expr)`; unary `+x`, `-x`, `not x`
- Arithmetic `+ - * / %`; comparison `< <= > >= == !=`; logical `and`, `or`
- Ternary `cond ? a : b`
- If/for/while/switch used as values
- History reference `x[1]`, `x[n]` (chainable: `x[1][1]` == `x[2]`)
- Member/namespace access `ta.sma`, `obj.field`
- Calls: `f(x)`, `ta.rsi(close, 14)`, `obj.method(...)`, `T.new(...)`, `T.copy(obj)`
- Tuple `(a, b)` (single `(a,)`); destructure `let (a, b) = f();`
- Collections: array literal `[1, 2, 3]`, map literal `{"a": 1}`
