---
name: navi-authoring
description: Write and refactor Navi code for indicators, strategies, and libraries. Use when designing Navi logic; choosing series vs simple/const/input qualifiers; understanding the bar-by-bar execution model, var/varip, and rollback; handling na; using history references (x[1]); avoiding repainting; working with arrays/maps/matrices; adding inputs; looking up standard-library functions (ta/math/str/strategy/plot/…); or structuring clean, non-repainting scripts.
---

Write Navi that is correct, readable, and easy to validate. Navi is a Rust-style
language (`.nvs`) for indicators and strategies. All examples use Navi syntax.

## Reference map

This skill's detail lives in `references/`. Load the file that matches the task:

| Read this | When you need to… |
|-----------|-------------------|
| [references/syntax.md](references/syntax.md) | Look up surface syntax — blocks, declarations, control flow, functions (`fn`/`method`/`property`/`staticmethod`/`staticproperty`/`operator`), struct/enum/newtype, imports, the statement/expression catalog. |
| [references/execution-model.md](references/execution-model.md) | Reason about *how scripts run* — bar-by-bar execution, `const`/`input`/`simple`/`series` qualifiers, `var`/`varip`/rollback, `na` handling, history references, and avoiding repainting. **Start here for most subtle bugs.** |
| [references/stdlib.md](references/stdlib.md) | Find a built-in — prelude names, `ta`/`math`/`str`/`array`/`map`/`matrix`, drawing (`plot`/`Label`/`Line`/`Box`/`Table`), `strategy`, and enum/constant namespaces, with multi-return tuple shapes. |
| [references/patterns.md](references/patterns.md) | Reach for a proven idiom or template — indicator/strategy/library skeletons, warmup guards, stateful accumulators, cross logic, rolling windows, divergence, plus pitfalls, performance, and debugging. |

## Workflow

1. **Identify the script type** — `indicator()` for plotting, `strategy()` for
   backtesting/orders, `library()` for reusable exports.
2. **Define inputs first** — `input.int/float/bool/string/source/…`; validate
   with `minval`/`maxval`; keep input names stable (they persist in UI/state).
3. **Model types deliberately** — treat `series` as per-bar streams; use `var`
   for state that must persist across bars; `const`/`input` only for values that
   never change during the run.
4. **Compute with bar-by-bar semantics** — prefer pure series expressions; keep
   loops small and bounded; be explicit about first-bar initialization.
5. **Handle history carefully** — `x[1]` reads the previous bar; guard early
   bars with `na()`; never reach forward in time.
6. **Default to non-repainting** — don't depend on unconfirmed bar state; isolate
   and document any real-time behavior.
7. **Make outputs readable** — one concept per plot, stable titles/ordering,
   consistent colors; guard `na` where relevant.

## Conventions

- Short, descriptive names (`src`, `len`, `maFast`, `maSlow`).
- Section scripts: inputs → calculation → signals → plots.
- Refactors preserve behavior unless a change was explicitly requested.
- Code comments describe semantics directly; never cite external products.

## Minimal cheatsheet

Full detail is in the references; this is just the shape of things.

- **Qualifiers** flow one way: `const → input → simple → series`. A `series`
  value can't be used where `simple`/`input`/`const` is required (e.g. most
  `ta.*` lengths). → [execution-model.md](references/execution-model.md)
- **Declaration modes**: `let` re-inits every bar; `var` inits once and persists
  (rolls back on real-time ticks); `varip` persists with **no** rollback (can
  repaint). → [execution-model.md](references/execution-model.md)
- **na**: `na(x)` tests, `nz(x, d)` replaces with default, `fixnan(x)` reuses
  last good value. Never assume `na` == 0.
- **History**: `x[1]` is the previous bar's value; `na` on early bars; promotes
  the qualifier to `series`; chains as `x[1][1] == x[2]`.
- **Declarations vs reassignment**: `let x = …;` declares; bare `x = …;`
  reassigns. Tuples use `(a, b)` and must be destructured immediately.
- **Everything is an expression**: `if`/`for`/`while`/`switch` return values. No
  `return` keyword; no recursion.

## Starter templates

Minimal indicator:

```navi
indicator("My Indicator", overlay: true);

let len = input.int(14, "Length", minval: 1);
let src = input.source(close, "Source");

let ma = ta.sma(src, len);
plot(ma, "SMA", color: color.ORANGE);
```

Minimal strategy:

```navi
strategy("MA Crossover", overlay: true);

let fast = ta.ema(close, input.int(10, "Fast", minval: 1));
let slow = ta.ema(close, input.int(20, "Slow", minval: 1));

if fast > slow and fast[1] <= slow[1] {
    strategy.entry("L", Direction.Long);
}
if fast < slow and fast[1] >= slow[1] {
    strategy.entry("S", Direction.Short);
}

plot(fast, "Fast");
plot(slow, "Slow");
```

More templates (including a `library`) and idioms are in
[references/patterns.md](references/patterns.md).
