# Navi Patterns & Templates

Reusable idioms, ready-to-adapt templates, and the mistakes worth avoiding.
Assumes the [execution model](execution-model.md) (bar-by-bar, `var`, `na`,
history) is understood.

## Table of Contents

- [Quick templates](#quick-templates)
- [Core patterns](#core-patterns)
- [Advanced patterns](#advanced-patterns)
- [Common pitfalls](#common-pitfalls)
- [Performance](#performance)
- [Debugging](#debugging)
- [Output expectations](#output-expectations)

## Quick templates

**Minimal indicator**

```navi
indicator("My Indicator", overlay: true);

let len = input.int(14, "Length", minval: 1);
let src = input.source(close, "Source");

let ma = ta.sma(src, len);
plot(ma, "SMA", color: color.ORANGE);
```

**Minimal strategy**

```navi
strategy("MA Crossover", overlay: true);

let fastLen = input.int(10, "Fast", minval: 1);
let slowLen = input.int(20, "Slow", minval: 1);

let fast = ta.ema(close, fastLen);
let slow = ta.ema(close, slowLen);

let longSignal  = fast > slow and fast[1] <= slow[1];
let shortSignal = fast < slow and fast[1] >= slow[1];

if longSignal {
    strategy.entry("L", Direction.Long);
}
if shortSignal {
    strategy.entry("S", Direction.Short);
}

plot(fast, "Fast");
plot(slow, "Slow");
```

**Reusable library**

```navi
//@description Shared moving-average helpers.
library("MaLib");

//@function Simple moving average of a source.
//@param src The input series.
//@param length The averaging window.
//@returns The SMA series.
export fn smaOf(src: series float, length: simple int): series float {
    ta.sma(src, length);
}

export enum Side { Long, Short, }
```

Import it elsewhere with `use MaLib as lib;` then call `lib.smaOf(close, 20)`.

## Core patterns

**First-bar / warmup guard** — a rolling function is `na` until it has enough
data; gate output on readiness.

```navi
let len = input.int(14, "Length", minval: 1);
let ma  = ta.sma(close, len);
plot(not na(ma) ? ma : na, "SMA");
```

**Stateful accumulator** — `var` keeps a running total across bars.

```navi
var sum: float = 0.0;
sum += nz(close, 0.0);
plot(sum, "Cumulative close");
```

**Conditional running value** — update only when a condition holds.

```navi
var peak: float = na;
if na(peak) or high > peak {
    peak = high;
}
plot(peak, "Peak");
```

**Explicit cross** — spell out the crossing with history references when the
exact `>` vs `>=` boundary matters (equivalent to `ta.crossover`).

```navi
let fast = ta.ema(close, 10);
let slow = ta.ema(close, 20);

let crossOver  = fast > slow and fast[1] <= slow[1];
let crossUnder = fast < slow and fast[1] >= slow[1];

plot_shape(crossOver,  title: "XOver",  style: Shape.TriangleUp,   location: Location.BelowBar);
plot_shape(crossUnder, title: "XUnder", style: Shape.TriangleDown, location: Location.AboveBar);
```

**Rolling window with a persistent array** — a `var` array grows across bars;
trim it to a fixed length.

```navi
var window = Array.new<float>(0);
window.push(close);
if window.size() > 50 {
    window.shift();
}
plot(window.avg(), "Rolling avg");
```

**Multi-return via tuple destructuring**

```navi
let (macdLine, signalLine, hist) = ta.macd(close, 12, 26, 9);
plot(macdLine, "MACD");
plot(signalLine, "Signal");
plot(hist, "Hist", style: PlotStyle.Histogram);
```

**Loop as an expression** — a loop returns its final iteration's value.

```navi
let ohlc = Array.from(open, high, low, close);
let ref  = ta.sma(close, 20);

let count = 0;
let above = for v in ohlc {
    if v > ref { count += 1; }
    count;
};
plot(above, "Count > SMA");
```

**Intra-bar state (`varip`)** — only when you genuinely need tick-level tracking
(can repaint).

```navi
varip rtHigh: float = na;
rtHigh = na(rtHigh) ? high : math.max(rtHigh, high);
plot(rtHigh, "Realtime high");
```

## Advanced patterns

**Selectable MA type via `switch`** — expose a string input, branch on it.

```navi
let maType = input.string("EMA", "MA type", options: ["EMA", "SMA", "RMA", "WMA"]);
let len    = input.int(20, "Length", minval: 1);

let ma = switch maType {
    "EMA" => ta.ema(close, len);
    "SMA" => ta.sma(close, len);
    "RMA" => ta.rma(close, len);
    => ta.wma(close, len);
};
plot(ma);
```

**Pivot-based divergence scaffold** — combine pivots, `valuewhen`, and history
to compare the current swing against the previous one.

```navi
let len = input.int(5, "Pivot Legs", minval: 1);

let ph = ta.pivothigh(len, len);          // na except on confirmed pivots
let havePivot = not na(ph);

// price and oscillator at the last two confirmed pivot highs
let osc = ta.rsi(close, 14);
let prevPivotPrice = ta.valuewhen(havePivot, high, 1);
let currPivotPrice = ta.valuewhen(havePivot, high, 0);
let prevPivotOsc   = ta.valuewhen(havePivot, osc, 1);
let currPivotOsc   = ta.valuewhen(havePivot, osc, 0);

let bearishDiv = havePivot
    and currPivotPrice > prevPivotPrice
    and currPivotOsc  < prevPivotOsc;

plot_shape(bearishDiv, title: "Bear Div", style: Shape.TriangleDown, location: Location.AboveBar);
```

**Conditional plot / display control** — plot `na` to hide, or route a plot to
specific panes with `display`.

```navi
let showMa = input.bool(true, "Show MA");
let ma = ta.sma(close, 20);
plot(showMa ? ma : na, "MA", display: display.PANE);
```

## Common pitfalls

- Don't assume `na` behaves like `0`; handle it explicitly (`na`, `nz`, `fixnan`).
- Avoid exact float equality (`==`) unless the inputs are known to be discrete.
- With `ta.cross*`, confirm the `>` vs `>=` boundary matches your intent.
- Keep `var` intentional — overusing it makes state hard to reason about.
- Length arguments must be `simple`/`input`, not `series`; a per-bar-changing
  length is a type error (see [qualifiers](execution-model.md#type-qualifiers-const--input--simple--series)).
- Keep plot ordering stable — users and tests rely on it.
- Tuples can only be returned from functions and immediately destructured — not
  stored, passed, or nested.
- Navi has no recursion; use loops.

## Performance

- Prefer built-in `ta.*` over hand-rolled loops — they are optimized and correct
  at the boundaries.
- Keep loops short and bounded; avoid per-bar O(n) work where n grows unbounded.
- Don't build large strings every bar.
- Extend history with `max_bars_back` only as far as you actually reference.

## Debugging

- Add temporary `plot`s of intermediate series to see where a value goes wrong.
- Use `log.info(String.from(x))` to trace values per bar.
- Reduce to a minimal reproducer; replace complex expressions with named
  variables to isolate where `na` first appears.

## Output expectations

- When implementing a script, produce complete code with: inputs, clear
  sectioning (inputs → calculation → signals → plots), and at least one `na`
  guard where relevant.
- When refactoring, keep behavior identical unless a change was explicitly
  requested.
