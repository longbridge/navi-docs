# Navi Standard Library Reference

The **prelude** is auto-loaded — its names are available with no prefix. The
**stdlib** namespaces are auto-imported under short aliases (`ta`, `math`,
`str`, `array`, …). This file is a member map; call syntax and qualifier rules
are in [syntax.md](syntax.md) and [execution-model.md](execution-model.md).

Enumerated options are **PascalCase enums** — `Location.BelowBar`,
`Shape.TriangleUp`, `PlotStyle.Histogram`, `Size.Normal`, `color.RED` — not
lowercase namespace constants.

## Table of Contents

- [Prelude (no prefix)](#prelude-no-prefix)
- [High-frequency signatures](#high-frequency-signatures)
- [`ta` — technical analysis](#ta--technical-analysis)
- [`math` — mathematics](#math--mathematics)
- [`str` — strings](#str--strings)
- [`array` — arrays](#array--arrays)
- [`map` — key-value maps](#map--key-value-maps)
- [`matrix` — 2D matrices](#matrix--2d-matrices)
- [`color` — colors](#color--colors)
- [`input` — user inputs](#input--user-inputs)
- [Drawing namespaces (label / line / box / linefill / polyline / table)](#drawing-namespaces)
- [`chart` — chart info](#chart--chart-info)
- [`strategy` — strategy API](#strategy--strategy-api)
- [Data & state namespaces](#data--state-namespaces)
- [Enum types](#enum-types)

## Prelude (no prefix)

Available in every script without import.

- **Candlestick data** — `open`, `high`, `low`, `close`, `volume`, `hl2`,
  `hlc3`, `hlcc4`, `ohlc4`, `bar_index`, `last_bar_index`, `last_bar_time`
- **Time** — `time`, `time_close`, `time_now`, `year`, `month`, `day_of_month`,
  `day_of_week`, `hour`, `minute`, `second`, `weekofyear`, `timestamp()`
- **Drawing** — `plot()`, `plot_shape()`, `plot_char()`, `plot_arrow()`,
  `plot_bar()`, `plot_candle()`, `bar_color()`, `bg_color()`, `fill()`,
  `hline()`
- **Script declarations** — `indicator()`, `strategy()`, `library()`
- **na handling** — `na()`, `nz()`, `fixnan()`
- **Type conversions** — `bool()`, `int()`, `float()`, `string()`, `color()`
- **Alerts** — `alert()`, `alert_condition()`
- **Inputs** — `input()` (overloaded for int/float/bool/color/string/source)
- **History buffer** — `max_bars_back()`
- **Newtypes (drawing handles)** — `plot`, `hline`, `label`, `line`,
  `linefill`, `box`, `polyline`, `table`, `plot_style`, `plot_line_style`,
  `plot_display`, `plot_simple_display`, `hline_style`, `text_format`

## High-frequency signatures

The calls you reach for constantly. Length arguments are usually `simple int`
(see [qualifiers](execution-model.md#type-qualifiers-const--input--simple--series)).

```navi
// Inputs
let len = input.int(14, "Length", minval: 1);
let src = input.source(close, "Source");
let maType = input.string("EMA", "MA type", options: ["EMA", "SMA", "RMA", "WMA"]);

// Moving averages / oscillators
let ma  = ta.sma(src, len);          // also ta.ema, ta.rma, ta.wma, ta.hma …
let r   = ta.rsi(close, 14);
let a   = ta.atr(14);

// Multi-return (destructure with a tuple)
let (macdLine, signalLine, hist) = ta.macd(close, 12, 26, 9);
let (basis, upper, lower)        = ta.bb(close, 20, 2.0);

// Plotting — enum options are PascalCase
plot(ma, "MA", color: color.ORANGE, linewidth: 2);
plot_shape(ta.crossover(ma, close), title: "X", style: Shape.TriangleUp, location: Location.BelowBar);
hline(0.0, "Zero", color: color.GRAY);

// Drawings
label.new(bar_index, high, str.tostring(close, "#.##"));

// Strategy — direction is the Direction enum
strategy.entry("Long", Direction.Long);
strategy.close("Long");
```

## `ta` — technical analysis

- Moving averages: `sma`, `ema`, `rma`, `wma`, `hma`, `alma`, `swma`, `vwma`,
  `linreg`
- Oscillators: `rsi`, `cci`, `cmo`, `cog`, `mfi`, `mom`, `roc`, `tsi`, `wpr`,
  `stoch`, `rci`
- Bands/channels: `bb`, `bbw`, `kc`, `kcw`, `atr`, `tr`, `supertrend`, `sar`
- Statistics: `stdev`, `variance`, `correlation`, `dev`, `median`, `mode`,
  `percentile_linear_interpolation`, `percentile_nearest_rank`, `percentrank`
- Extremes: `highest`, `lowest`, `highestbars`, `lowestbars`, `max`, `min`,
  `range`
- Conditions: `crossover`, `crossunder`, `cross`, `rising`, `falling`,
  `barssince`, `valuewhen`, `change`
- Accumulation: `cum`, `vwap`
- Volume: `accdist`, `iii`, `nvi`, `obv`, `pvi`, `pvt`, `wad`, `wvad`
- Pivots: `pivothigh`, `pivotlow`

**Multi-return tuple shapes:** `bb → (basis, upper, lower)`,
`kc → (basis, upper, lower)`, `macd → (macd, signal, hist)`,
`dmi → (plus, minus, adx)`, `supertrend → (value, direction)`,
`vwap → (vwap, upper, lower)`.

## `math` — mathematics

- Constants: `pi`, `e`, `phi`, `rphi`
- Basic: `abs`, `ceil`, `floor`, `round`, `round_to_mintick`, `sign`, `sqrt`,
  `pow`, `exp`, `log`, `log10`
- Trig (degrees): `cos`, `sin`, `tan`, `acos`, `asin`, `atan`, `todegrees`,
  `toradians`
- Aggregation: `max`, `min`, `avg` (variadic), `sum` (rolling)
- Other: `random`

## `str` — strings

`tostring`, `format`, `tonumber`, `length`, `contains`, `startswith`,
`endswith`, `pos`, `match` (regex), `lower`, `upper`, `trim`, `repeat`,
`replace`, `replace_all`, `split`, `substring`, `join`, `format_time`

## `array` — arrays

- Creation: `Array.new<T>()`, `Array.from<T>()` (PascalCase staticmethod)
- Access: `get`, `set`, `first`, `last`, `size`
- Mutation: `push`, `pop`, `shift`, `unshift`, `insert`, `remove`, `clear`,
  `fill`, `reverse`, `sort`, `concat`, `copy`, `slice`
- Aggregation: `avg`, `sum`, `min`, `max`, `median`, `mode`, `range`, `stdev`,
  `variance`, `covariance`, `standardize`
- Search: `includes`, `indexof`, `lastindexof`, `binary_search`,
  `binary_search_leftmost`, `binary_search_rightmost`
- Other: `abs`, `every`, `some`, `join`, `percentile_linear_interpolation`,
  `percentile_nearest_rank`, `percentrank`, `sort_indices`

## `map` — key-value maps

Literal `{"key": value, ...}` (key must be int/float/bool/string/color/enum).
`new<K,V>`, methods: `get`, `put`, `remove`, `contains`, `keys`, `values`,
`size`, `clear`, `put_all`, `copy`.

## `matrix` — 2D matrices

- Creation: `new<T>`
- Access: `get`, `set`, `rows`, `columns`, `elements_count`, `row`, `col`
- Mutation: `add_row`, `add_col`, `remove_row`, `remove_col`, `fill`, `reshape`,
  `reverse`, `swap_rows`, `swap_columns`, `sort`
- Math: `avg`, `min`, `max`, `median`, `mode`, `sum`, `diff`, `multi`, `pow`,
  `det`, `trace`, `rank`, `inv`, `pinv`, `eigenvalues`, `eigenvectors`, `kron`,
  `transpose`, `submatrix`, `concat`, `copy`
- Checks: `is_square`, `is_identity`, `is_diagonal`, `is_symmetric`,
  `is_antisymmetric`, `is_triangular`, `is_binary`, `is_zero`, `is_stochastic`,
  `is_antidiagonal`

## `color` — colors

Constants are **uppercase** properties: `color.AQUA`, `BLACK`, `BLUE`,
`FUCHSIA`, `GRAY`, `GREEN`, `LIME`, `MAROON`, `NAVY`, `OLIVE`, `ORANGE`,
`PURPLE`, `RED`, `SILVER`, `TEAL`, `WHITE`, `YELLOW`.

Functions: `new(color, transp)` (transp 0–100), `rgb(red, green, blue, transp)`,
`r(color)`, `g(color)`, `b(color)`, `t(color)`, `from_gradient(value,
bottom_value, top_value, bottom_color, top_color)`.

## `input` — user inputs

`int`, `float`, `bool`, `color`, `string`, `price`, `symbol`, `timeframe`,
`source`, `enum`, `session`, `time`, `text_area`. Common named options:
`minval`, `maxval`, `step`, `options`, `group`, `tooltip`.

## Drawing types

Drawing types use **PascalCase** in Navi: `Label`, `Line`, `Box`, `Linefill`,
`Polyline`, `Table`. Style/size options are the PascalCase enums in
[Enum types](#enum-types) (`LabelStyle`, `LineStyle`, `Size`, …).

**Calling convention** — static constructors use `Type.new(...)`, instance
methods can be called either way:

```navi
let lbl = Label.new(chart.Point.now(), "hi"); // static constructor
lbl.delete();                                  // receiver call
Label.delete(lbl);                             // Type.method(instance, ...) — also valid
```

**`Label`** — `new()`, `all`; methods `delete`, `copy`, `get_*`/`set_*`
(`set_x`, `set_y`, `set_xy`, `set_text`, `set_color`, `set_style`, `set_size`,
`set_textcolor`, `set_textalign`, `set_tooltip`, `set_xloc`, `set_yloc`,
`set_point`, `set_text_font_family`, `set_text_formatting`). Style arg takes
`LabelStyle`, size takes `Size`.

**`Line`** — `new()`, `all`; methods `delete`, `copy`, `get_*`/`set_*`
(`set_xy1`, `set_xy2`, `set_color`, `set_style`, `set_width`, `set_extend`,
`set_first_point`, `set_second_point`). Style arg takes `LineStyle`; extend
takes `Extend`.

**`Box`** — `new()`, `all`; methods `delete`, `copy`, `get_*`/`set_*`
(`set_lefttop`, `set_rightbottom`, `set_bg_color`, `set_border_color/style/width`,
`set_text`, `set_extend`, `set_text_*`, `set_top_left_point`,
`set_bottom_right_point`). Border style takes `LineStyle`.

**`Linefill`** — `new(line1, line2, color)`, `all`; `delete`, `get_line1`,
`get_line2`, `set_color`.

**`Polyline`** — `new(points, curved, closed, …)`, `all`; `delete`.

**`Table`** — `new(position, columns, rows, …)`; methods `cell`, `delete`,
`clear`, `merge_cells`, `set_position`, `set_bg_color`, `set_frame_*`,
`set_border_*`, and `cell_set_*` (`cell_set_text`, `cell_set_text_color/size`,
`cell_set_bg_color`, `cell_set_width/height`, `cell_set_tooltip`, …). Position
takes `Position`; alignment takes `TextHAlign`/`TextVAlign`.

## `chart` — chart info

Type `chart.Point` (fields `index`, `time`, `price`); static methods
`chart.Point.now(price)`, `chart.Point.from_time(time, price)`. Properties
`chart.bg_color`, `chart.fg_color`.

## `strategy` — strategy API

- Entry/exit: `entry()`, `exit()`, `order()`, `close()`, `close_all()`,
  `cancel()`, `cancel_all()`
- **Direction** is the `Direction` enum: `Direction.Long`, `Direction.Short`,
  `Direction.All` (used as `strategy.entry(id, Direction.Long)`)
- Account state: `equity`, `netprofit`, `netprofit_percent`, `grossprofit`,
  `grossloss`, `openprofit`, `position_size`, `position_avg_price`,
  `initial_capital`, `max_runup`, `max_drawdown`, `wintrades`, `losstrades`,
  `eventrades`, `avg_trade`, `opentrades`, `closedtrades`
- Currency: `convert_to_account()`, `convert_to_symbol()`, `account_currency`
- `strategy.risk` (`allow_entry_in`, `max_position_size`, `max_drawdown`,
  `max_intraday_filled_orders`, `max_intraday_loss`, `max_cons_loss_days`);
  `strategy.closedtrades` / `strategy.opentrades` (per-trade queries)
- `strategy()` declaration options use enums: `default_qty_type: DefaultQtyType`,
  `commission_type: CommissionType`, `scale: ScaleType`, `format: Format`

## Data & state namespaces

| Namespace | Contents |
|-----------|----------|
| `syminfo` | `ticker`, `tickerid`, `currency`, `basecurrency`, `timezone`, `session`, `type`, `mintick`, `pointvalue`, `description`, `prefix`, `root`, `sector`, `industry`, … |
| `timeframe` | `period`, `multiplier`, `isdaily`, `isdwm`, `isintraday`, `isminutes`, `ismonthly`, `isseconds`, `isweekly`, `in_seconds()`, `change()`, `from_seconds()` |
| `barstate` | `is_new`, `is_history`, `is_realtime`, `is_confirmed`, `is_first`, `is_last`, `is_last_confirmed_history` |
| `session` | `ismarket`, `ispremarket`, `ispostmarket`, `is_first_bar`, `is_last_bar`, `is_first_bar_regular`, `is_last_bar_regular` (session *type* is the `Session` enum) |
| `request` | `security(...)`, `earnings(...)`, `dividends(...)`, `splits(...)` — data on another symbol/timeframe (avoid look-ahead) |
| `log` | `info()`, `warning()`, `error()` |
| `runtime` | `error()` |
| `display` | flags combined with `+`/`-`: `display.ALL`, `display.NONE`, `display.PANE`, `display.DATA_WINDOW`, `display.STATUS_LINE`, `display.PRICE_SCALE`, `display.SCREENER` |

## Enum types

All PascalCase; access variants as `EnumName.Variant`.

| Enum | Variants |
|------|----------|
| `PlotStyle` | `Line`, `LineBr`, `Area`, `AreaBr`, `Circles`, `Columns`, `Cross`, `Histogram`, `Stepline`, `SteplineDiamond`, `SteplineBr` |
| `Shape` | `ArrowDown`, `ArrowUp`, `Circle`, `Cross`, `Diamond`, `Flag`, `LabelDown`, `LabelUp`, `Square`, `TriangleDown`, `TriangleUp`, `XCross` |
| `LabelStyle` | `NoLabel`, `ArrowDown/Up`, `Circle`, `Cross`, `Diamond`, `Flag`, `LabelCenter`, `Down`, `Left`, `LowerLeft`, `LowerRight`, `Right`, `Up`, `UpperLeft`, `UpperRight`, `Square`, `TextOutline`, `TriangleDown/Up`, `XCross` |
| `LineStyle` | `Solid`, `Dashed`, `Dotted`, `ArrowLeft`, `ArrowRight`, `ArrowBoth` |
| `HlineStyle` | `Solid`, `Dashed`, `Dotted` |
| `Location` | `AboveBar`, `BelowBar`, `Top`, `Bottom`, `Absolute` |
| `Size` | `Auto`, `Tiny`, `Small`, `Normal`, `Large`, `Huge` |
| `Extend` | `None`, `Left`, `Right`, `Both` |
| `Position` | `TopLeft`, `TopCenter`, `TopRight`, `MiddleLeft`, `MiddleCenter`, `MiddleRight`, `BottomLeft`, `BottomCenter`, `BottomRight` |
| `TextHAlign` | `Left`, `Center`, `Right` |
| `TextVAlign` | `Top`, `Center`, `Bottom` |
| `TextWrap` | `Auto`, `None` |
| `FontFamily` | `Default`, `Monospace` |
| `Xloc` | `BarIndex`, `BarTime` |
| `Yloc` | `Price`, `AboveBar`, `BelowBar` |
| `Format` | `Inherit`, `Price`, `Volume`, `Percent`, `Mintick` |
| `AlertFreq` | `All`, `OncePerBar`, `OncePerBarClose` |
| `Session` | `Regular`, `Extended` |
| `ScaleType` | `None`, `Left`, `Right` |
| `SortOrder` | `Ascending`, `Descending` |
| `DayOfWeek` | `Sunday`(0) .. `Saturday`(6) |
| `Direction` | `Long`, `Short`, `All` |
| `OcaType` | `None`, `Cancel`, `Reduce` |
| `CommissionType` | `Percent`, `CashPerOrder`, `CashPerContract` |
| `DefaultQtyType` | `PercentOfEquity`, `Fixed`, `Cash` |
| `PivotType` | (used by `ta` pivot helpers) |
| `BarmergeGaps` | `On`, `Off` |
| `BarmergeLookahead` | `On`, `Off` |
| `EarningsField` | `Actual`, `Estimate`, `Standardized` |
| `DividendsField` | `Gross`, `Net` |
| `SplitsField` | `Numerator`, `Denominator` |
| `Currency` | ISO 4217 codes (`USD`, `EUR`, `GBP`, `JPY`, `BTC`, `ETH`, …) |
